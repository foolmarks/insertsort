/*----------------------------------------------------------------------------------
  Insertion sorter
  
  Ver 1.0

  Arguments:

  startAddr            : start addr of list to be sorted
  listSize             : size of list to be sorted
  sortList[memSize]    : creates an interface to list to be sorted.
----------------------------------------------------------------------------------*/

#include "sorter_defs_v1_0.h"



void insertsort(ADDR_t startAddr, LSIZE_t listSize, DATA_t sortList[memSize])
{
  	/*----------------------------------------------------------
	 * Pragmas for startAddr, listSize and the control ports
	 ----------------------------------------------------------*/
	// these pragmas bundle the input arguments into an AXI lite
	// interface for software control
	 #pragma HLS INTERFACE s_axilite port=startAddr   bundle=CTL
	 #pragma HLS INTERFACE s_axilite port=listSize    bundle=CTL
	 #pragma HLS INTERFACE s_axilite port=return      bundle=CTL



	/*----------------------------------------------------------
	 * Pragmas for the memory interface
	 ----------------------------------------------------------*/
	// this pragma will implement the memory interface as AXI-MM
     #pragma HLS INTERFACE m_axi port=sortList offset=off

	// these pragmas together will implement the interface to the
	// memory as a single port BRAM
    //  #pragma HLS INTERFACE bram port=sortList
    //  #pragma HLS RESOURCE variable=sortList core=RAM_1P
    

	   for (unsigned int i = startAddr+1; i < listSize+startAddr; i++)
	   {
		   int j;
		   DATA_t temp;

	       temp = sortList[i];
	       j = i-1;

	       while (j >= startAddr && sortList[j] > temp)
	       {
	    	   sortList[j+1] = sortList[j];
	           j = j-1;
	       }
	       sortList[j+1] = temp;
	   }


}
 /*--------------------------------------------------------------------------------
  End of File: insertsort.cpp
----------------------------------------------------------------------------------*/
