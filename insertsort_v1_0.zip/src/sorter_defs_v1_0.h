#ifndef _SORTER_DEFS_
#define _SORTER_DEFS_

#include <cstdlib>
#include <ctime>

#include <iostream>
#include <iomanip>

using namespace std;



/*-------------------------------------------
  TYPES & CONSTANTS
-------------------------------------------*/

// this defines the total size of the external memory
const unsigned int memSize = 1024;
  
// this defines the type of the list elements
typedef unsigned int DATA_t;

// this defines the type of the list start address
typedef unsigned int ADDR_t;

// this defines the type of the list size
typedef unsigned int LSIZE_t;


/*-------------------------------------------
  FUNCTIONS PROTOTYPES
-------------------------------------------*/
void insertsort(ADDR_t startAddr, LSIZE_t listSize, DATA_t sortList[memSize]);

void chkResults(DATA_t testArray[memSize], ADDR_t startAddr, LSIZE_t listSize);


#endif


  
